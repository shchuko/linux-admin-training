# Date&time display utility

Create `configure`:

```bash
$ autoconf
```

